package com.faiza.qrcodeproject;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import com.yuyh.jsonviewer.library.JsonRecyclerView;

public class JSONViewActivity extends AppCompatActivity {
    JsonRecyclerView jsonRecyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jsonview);
        jsonRecyclerView = findViewById(R.id.rv_json);

        if (getIntent().getExtras() != null) {
            Bundle bundle = getIntent().getExtras();
            jsonRecyclerView.bindJson(bundle.getString("dataJSON"));
        }
    }
}